/* MMG5.8 proposer. Exact output convention reuses V3 extract_mmg_meshb.c.
 * No backend return code is a V4 scientific acceptance credential. */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mmg/mmg3d/libmmg3d.h"
int main(int argc,char **argv){
 MMG5_pMesh mesh=NULL;MMG5_pSol met=NULL;
 if(argc!=10){fprintf(stderr,"mesh sol output hgrad hausd hmin hmax memoryMB noinsert\n");return 2;}
 double grad=atof(argv[4]),haus=atof(argv[5]),hmin=atof(argv[6]),hmax=atof(argv[7]);
 int mem=atoi(argv[8]),noinsert=atoi(argv[9]);
 if(!isfinite(grad)||grad<1||!isfinite(haus)||haus<=0||!isfinite(hmin)||hmin<=0||!isfinite(hmax)||hmax<hmin||mem<1||(noinsert!=0&&noinsert!=1))return 3;
 MMG3D_Init_mesh(MMG5_ARG_start,MMG5_ARG_ppMesh,&mesh,MMG5_ARG_ppMet,&met,MMG5_ARG_end);
 if(!mesh||MMG3D_loadMesh(mesh,argv[1])!=1||MMG3D_loadSol(mesh,met,argv[2])!=1)return 4;
 if(MMG3D_Set_iparameter(mesh,met,MMG3D_IPARAM_verbose,3)!=1||
    MMG3D_Set_iparameter(mesh,met,MMG3D_IPARAM_mem,mem)!=1||
    MMG3D_Set_iparameter(mesh,met,MMG3D_IPARAM_nosizreq,1)!=1||
    MMG3D_Set_iparameter(mesh,met,MMG3D_IPARAM_noinsert,noinsert)!=1||
    MMG3D_Set_dparameter(mesh,met,MMG3D_DPARAM_hgrad,grad)!=1||
    MMG3D_Set_dparameter(mesh,met,MMG3D_DPARAM_hausd,haus)!=1||
    MMG3D_Set_dparameter(mesh,met,MMG3D_DPARAM_hmin,hmin)!=1||
    MMG3D_Set_dparameter(mesh,met,MMG3D_DPARAM_hmax,hmax)!=1)return 5;
 int status=MMG3D_mmg3dlib(mesh,met);fprintf(stdout,"V4_MMG_STATUS %d\n",status);fflush(stdout);
 if(status==MMG5_STRONGFAILURE)return 6;
 MMG5_int np,ne,nprism,nt,nquad,na,a,b,c,d,ref;double x,y,z;int corner,req;
 if(MMG3D_Get_meshSize(mesh,&np,&ne,&nprism,&nt,&nquad,&na)!=1||nprism||nquad)return 7;
 FILE *out=fopen(argv[3],"wb");if(!out)return 8;
 fprintf(out,"COUNTS %d %d %d %d\nVERTICES\n",(int)np,(int)ne,(int)nt,(int)na);
 for(MMG5_int i=0;i<np;i++){
  if(MMG3D_Get_vertex(mesh,&x,&y,&z,&ref,&corner,&req)!=1)return 9;
  fprintf(out,"%.17g %.17g %.17g %d %d %d\n",x,y,z,(int)ref,corner,req);
 }
 fprintf(out,"TETRAHEDRA\n");
 for(MMG5_int i=0;i<ne;i++){
  if(MMG3D_Get_tetrahedron(mesh,&a,&b,&c,&d,&ref,&req)!=1)return 9;
  fprintf(out,"%d %d %d %d %d %d\n",(int)a,(int)b,(int)c,(int)d,(int)ref,req);
 }
 fprintf(out,"TRIANGLES\n");
 for(MMG5_int i=0;i<nt;i++){
  if(MMG3D_Get_triangle(mesh,&a,&b,&c,&ref,&req)!=1)return 9;
  fprintf(out,"%d %d %d %d %d\n",(int)a,(int)b,(int)c,(int)ref,req);
 }
 fclose(out);MMG3D_Free_all(MMG5_ARG_start,MMG5_ARG_ppMesh,&mesh,MMG5_ARG_ppMet,&met,MMG5_ARG_end);
 return status==MMG5_SUCCESS?0:10;
}
